# Submission and extra information

* I added a section to check_images to print out the final results, in a format that can easily be matched to the tables provided.

* For the uploaded images section, I added an image of a Spaniel. AlexNet failed to identify the breed correctly, thinking it was a golden retriever (very similar).

* AlexNet was the fastest classifier (3 seconds), followed by ResNet (8 seconds), and VGG was the slowest at 29 seconds.
